# ECG PeerJS Signaling Server

Deploy to Railway:
1. Go to railway.app and sign up (free)
2. New Project → Deploy from GitHub repo
   OR New Project → Empty Project → Add Service → GitHub Repo
3. Point it at this folder (or upload the files)
4. Railway auto-detects Node.js and runs `npm start`
5. Copy the generated URL (e.g. ecg-peerserver.up.railway.app)
6. Update the game's peer config with that URL
